package com.example.myappli

data class CatFact(val fact: String, val length: Int)

data class CatFactsList(val data: List<CatFact>)
