package com.example.myappli

import retrofit2.http.GET

interface CatFactApi {
    @GET("fact")
    suspend fun getRandomFact(): CatFact

    @GET("facts")
    suspend fun getFactList(): CatFactsList
}
