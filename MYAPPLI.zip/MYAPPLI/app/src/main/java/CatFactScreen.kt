package com.example.myappli

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

@Composable
fun CatFactScreen() {
    val scope = rememberCoroutineScope()
    var singleFact by remember { mutableStateOf("Loading...") }
    var factList by remember { mutableStateOf<List<CatFact>>(emptyList()) }

    val retrofit = Retrofit.Builder()
        .baseUrl("https://catfact.ninja/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api = retrofit.create(CatFactApi::class.java)

    LaunchedEffect(Unit) {
        scope.launch(context = Dispatchers.IO) {
            try {
                val factResponse = api.getRandomFact()
                val listResponse = api.getFactList()

                singleFact = factResponse.fact
                factList = listResponse.data
            } catch (e: Exception) {
                Log.e("CatFact", "Error fetching data", e)
                singleFact = "Error fetching"
            }
        }
    }

    Column(modifier = Modifier.padding(all = 16.dp)) {
        Text("😺 Random Cat Fact:")
        Text(singleFact, modifier = Modifier.padding(all = 8.dp))

        Spacer(modifier = Modifier.height(16.dp))

        Text("📖 More Cat Facts:")

        LazyColumn {
            items(factList) { fact ->
                Text("• ${fact.fact}", modifier = Modifier.padding(all = 4.dp))
            }
        }
    }
}
