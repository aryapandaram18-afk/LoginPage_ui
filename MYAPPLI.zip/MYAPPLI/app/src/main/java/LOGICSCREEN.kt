package com.example.myappli
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.ui.unit.sp


import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontWeight.Companion.ExtraBold
import androidx.compose.ui.text.input.PasswordVisualTransformation

@SuppressLint("RememberReturnType")
@Composable
fun LOGICSCREEN() {
    var Student by remember {
        mutableStateOf(" ")
    }
    var Password by remember {
        mutableStateOf(" ")
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFe0f7fa),
                        Color(0xFFb2ebf2),
                        Color(0xFF80deea)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .background(Color.White.copy(alpha = 0.9f), shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp))
                    .padding(32.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.transparetboy),
                        contentDescription = "Login Illustration",
                        modifier = Modifier.size(180.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "READY TO LEARN?", fontSize = 31.sp, fontWeight = ExtraBold,)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Student Sign-In", fontSize = 16.sp)

                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = Student,
                        onValueChange = {Student=it},
                        label = { Text("Student-ID") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = Password,
                        onValueChange = {Password=it},

                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth()
             , visualTransformation = PasswordVisualTransformation()       )

                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {},
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Login")
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = { }) {
                        Text("Forgot password?")
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text("or sign in with")

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ggg),
                            contentDescription = "Google",
                            modifier = Modifier.size(48.dp).clickable { }
                        )
                        Image(
                            painter = painterResource(R.drawable.micc),
                            contentDescription = "Microsoft",
                            modifier = Modifier.size(48.dp).clickable { }
                        )
                    }
                }
            }
        }
    }
}
